import { pool, hrmsPool } from "../../config/mySqlDB.js";

/*
 * SQL only. No business rules here (those are in booking.service.js).
 *
 * Every function takes `db` first: pass a transaction connection or `pool`.
 *
 * DATE columns are always returned through DATE_FORMAT(..., '%Y-%m-%d').
 * mysql2 is configured with timezone +05:30, which would otherwise shift a
 * plain DATE back by one day when it is serialised to JSON.
 */

const num = (v) => (v === null || v === undefined ? null : Number(v));
const round2 = (n) => Math.round((Number(n) + Number.EPSILON) * 100) / 100;

const D = (col, alias) => `DATE_FORMAT(${col}, '%Y-%m-%d') AS ${alias}`;

/* ============================================================
 * ROW MAPPERS
 * ============================================================ */

export const mapBooking = (r) =>
  r && {
    ...r,
    booking_amount: num(r.booking_amount),
    total_trip_cost: num(r.total_trip_cost),
    balance_amount: round2(Number(r.total_trip_cost) - Number(r.booking_amount)),
    total_cost_manual: Boolean(r.total_cost_manual),
  };

const mapVehicle = (r) => ({
  ...r,
  price: num(r.price),
  line_total: round2(Number(r.price) * Number(r.no_of_vehicles)),
});

const mapPayment = (r) => ({ ...r, amount: num(r.amount) });

/* ============================================================
 * BOOKINGS
 * ============================================================ */

const BOOKING_SELECT = `
  b.id, b.booking_no, b.booking_prefix, b.quotation_id, b.lead_id, b.customer_id,
  b.status, b.booking_amount, b.total_trip_cost, b.total_cost_manual,
  b.travel_detail, b.pickup_location, b.pickup_time, b.drop_location, b.drop_time,
  ${D("b.travel_from", "travel_from")}, ${D("b.travel_to", "travel_to")},
  b.total_days, b.trip_type, b.pax, b.remarks, b.cancel_reason,
  b.confirmed_at, b.cancelled_at, b.created_by, b.updated_by, b.created_at, b.updated_at
`;

export const getBookingRow = async (db, id, { lock = false } = {}) => {
  const [rows] = await db.query(
    `SELECT ${BOOKING_SELECT} FROM bookings b WHERE b.id = ? LIMIT 1 ${lock ? "FOR UPDATE" : ""}`,
    [id],
  );
  return mapBooking(rows[0]) ?? null;
};

export const getBookingByQuotationId = async (db, quotationId) => {
  const [rows] = await db.query(
    `SELECT b.id, b.booking_no, b.status FROM bookings b WHERE b.quotation_id = ? LIMIT 1`,
    [quotationId],
  );
  return rows[0] ?? null;
};

export const insertBooking = async (db, d) => {
  const [result] = await db.query(
    `INSERT INTO bookings (
       booking_no, booking_prefix, quotation_id, lead_id, customer_id,
       status, booking_amount, total_trip_cost, total_cost_manual,
       travel_detail, pickup_location, pickup_time, drop_location, drop_time,
       travel_from, travel_to, total_days, trip_type, pax, remarks,
       confirmed_at, created_by, updated_by
     ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ${
       d.status === "Confirmed" ? "NOW()" : "NULL"
     }, ?, ?)`,
    [
      d.booking_no, d.booking_prefix, d.quotation_id, d.lead_id, d.customer_id,
      d.status, d.booking_amount, d.total_trip_cost, d.total_cost_manual ? 1 : 0,
      d.travel_detail, d.pickup_location, d.pickup_time, d.drop_location, d.drop_time,
      d.travel_from, d.travel_to, d.total_days, d.trip_type, d.pax, d.remarks,
      d.created_by, d.created_by,
    ],
  );
  return result.insertId;
};

// Columns PATCH/service code may change. Anything else is ignored.
const UPDATABLE_BOOKING_COLUMNS = new Set([
  "booking_no", "booking_prefix", "status", "booking_amount", "total_trip_cost",
  "total_cost_manual", "travel_detail", "pickup_location", "pickup_time",
  "drop_location", "drop_time", "travel_from", "travel_to", "total_days",
  "trip_type", "pax", "remarks", "cancel_reason", "updated_by",
]);

// `raw` lets the service set timestamp columns to NOW() / NULL without params.
export const updateBookingFields = async (db, id, fields, raw = {}) => {
  const sets = [];
  const values = [];

  for (const [col, val] of Object.entries(fields)) {
    if (!UPDATABLE_BOOKING_COLUMNS.has(col)) continue;
    sets.push(`\`${col}\` = ?`);
    values.push(val);
  }
  for (const [col, expr] of Object.entries(raw)) {
    if (!["confirmed_at", "cancelled_at"].includes(col)) continue;
    sets.push(`\`${col}\` = ${expr === "NOW()" ? "NOW()" : "NULL"}`);
  }
  if (sets.length === 0) return;

  values.push(id);
  await db.query(`UPDATE bookings SET ${sets.join(", ")} WHERE id = ?`, values);
};

/* ============================================================
 * QUOTATION (read only, plus status change on accept)
 * ============================================================ */

export const getQuotationForBooking = async (db, id, { lock = false } = {}) => {
  const [rows] = await db.query(
    `SELECT q.id, q.quote_no, q.customer_id, q.lead_id, q.status,
            ${D("q.quote_date", "quote_date")},
            q.travel_detail, q.pickup_location, q.pickup_time,
            q.drop_location, q.drop_time,
            ${D("q.travel_from", "travel_from")}, ${D("q.travel_to", "travel_to")},
            q.total_days, q.trip_type, q.pax, q.remarks, q.created_by
       FROM quotations q
      WHERE q.id = ?
      LIMIT 1 ${lock ? "FOR UPDATE" : ""}`,
    [id],
  );
  return rows[0] ?? null;
};

export const getQuotationOptions = async (db, quotationId) => {
  const [rows] = await db.query(
    `SELECT id, quotation_id, sr_no, seats, vehicle_name, category_name,
            no_of_vehicles, description, discounted_price
       FROM quotation_vehicle_options
      WHERE quotation_id = ?
      ORDER BY sr_no, id`,
    [quotationId],
  );
  return rows.map((r) => ({ ...r, discounted_price: num(r.discounted_price) }));
};

export const getQuotationCharges = async (db, quotationId) => {
  const [rows] = await db.query(
    `SELECT charge_name, charge_detail, is_included, sort_order
       FROM quotation_other_charges
      WHERE quotation_id = ?
      ORDER BY sort_order, id`,
    [quotationId],
  );
  return rows;
};

export const getQuotationNotes = async (db, quotationId) => {
  const [rows] = await db.query(
    `SELECT note_text, sort_order
       FROM quotation_notes
      WHERE quotation_id = ?
      ORDER BY sort_order, id`,
    [quotationId],
  );
  return rows;
};

export const setQuotationStatus = async (db, id, status) => {
  await db.query(`UPDATE quotations SET status = ? WHERE id = ?`, [status, id]);
};

export const getQuotationSummary = async (db, id) => {
  const [rows] = await db.query(
    `SELECT id, quote_no, status, ${D("quote_date", "quote_date")} FROM quotations WHERE id = ?`,
    [id],
  );
  return rows[0] ?? null;
};

/* ============================================================
 * CUSTOMER
 * ============================================================ */

export const getCustomer = async (db, id) => {
  const [rows] = await db.query(
    `SELECT id, uuid, firstName, middleName, lastName,
            TRIM(CONCAT_WS(' ', firstName, middleName, lastName)) AS fullName,
            customerPhone, alternatePhone, customerEmail,
            companyName, customerCity, countryName
       FROM customers
      WHERE id = ?
      LIMIT 1`,
    [id],
  );
  return rows[0] ?? null;
};

/* ============================================================
 * LEAD (status sync when a booking becomes Confirmed)
 * ============================================================ */

export const getLeadStatus = async (db, leadId) => {
  const [rows] = await db.query(
    `SELECT id, status FROM leads WHERE id = ? LIMIT 1 FOR UPDATE`,
    [leadId],
  );
  return rows[0] ?? null;
};

export const setLeadStatus = async (db, leadId, status) => {
  await db.query(`UPDATE leads SET status = ? WHERE id = ?`, [status, leadId]);
};

export const insertLeadStatusHistory = async (
  db,
  { lead_id, old_status, new_status, changed_by },
) => {
  await db.query(
    `INSERT INTO lead_status_history (lead_id, old_status, new_status, changed_by)
     VALUES (?, ?, ?, ?)`,
    [lead_id, old_status, new_status, changed_by],
  );
};

/* ============================================================
 * VEHICLES / CHARGES / NOTES
 * ============================================================ */

export const listVehicles = async (db, bookingId) => {
  const [rows] = await db.query(
    `SELECT id, booking_id, quotation_option_id, sr_no, seats, vehicle_name,
            category_name, no_of_vehicles, description, price
       FROM booking_vehicles
      WHERE booking_id = ?
      ORDER BY sr_no, id`,
    [bookingId],
  );
  return rows.map(mapVehicle);
};

export const replaceVehicles = async (db, bookingId, rows) => {
  await db.query(`DELETE FROM booking_vehicles WHERE booking_id = ?`, [bookingId]);
  if (!rows.length) return;
  await db.query(
    `INSERT INTO booking_vehicles
       (booking_id, quotation_option_id, sr_no, seats, vehicle_name,
        category_name, no_of_vehicles, description, price)
     VALUES ?`,
    [
      rows.map((r) => [
        bookingId, r.quotation_option_id, r.sr_no, r.seats, r.vehicle_name,
        r.category_name, r.no_of_vehicles, r.description, r.price,
      ]),
    ],
  );
};

export const listCharges = async (db, bookingId) => {
  const [rows] = await db.query(
    `SELECT id, charge_name, charge_detail, is_included, sort_order
       FROM booking_charges
      WHERE booking_id = ?
      ORDER BY sort_order, id`,
    [bookingId],
  );
  return rows.map((r) => ({ ...r, is_included: Boolean(r.is_included) }));
};

export const replaceCharges = async (db, bookingId, rows) => {
  await db.query(`DELETE FROM booking_charges WHERE booking_id = ?`, [bookingId]);
  if (!rows.length) return;
  await db.query(
    `INSERT INTO booking_charges
       (booking_id, charge_name, charge_detail, is_included, sort_order)
     VALUES ?`,
    [rows.map((r) => [bookingId, r.charge_name, r.charge_detail, r.is_included ? 1 : 0, r.sort_order])],
  );
};

export const listNotes = async (db, bookingId) => {
  const [rows] = await db.query(
    `SELECT id, note_text, sort_order
       FROM booking_notes
      WHERE booking_id = ?
      ORDER BY sort_order, id`,
    [bookingId],
  );
  return rows;
};

export const replaceNotes = async (db, bookingId, rows) => {
  await db.query(`DELETE FROM booking_notes WHERE booking_id = ?`, [bookingId]);
  if (!rows.length) return;
  await db.query(
    `INSERT INTO booking_notes (booking_id, note_text, sort_order) VALUES ?`,
    [rows.map((r) => [bookingId, r.note_text, r.sort_order])],
  );
};

/* ============================================================
 * PAYMENTS
 * ============================================================ */

const PAYMENT_SELECT = `
  id, booking_id, label, ${D("due_date", "due_date")}, amount, payment_mode,
  paid_to, status, ${D("paid_date", "paid_date")}, remarks, sort_order,
  created_at, updated_at
`;

export const listPayments = async (db, bookingId) => {
  const [rows] = await db.query(
    `SELECT ${PAYMENT_SELECT}
       FROM booking_payments
      WHERE booking_id = ?
      ORDER BY sort_order, due_date IS NULL, due_date, id`,
    [bookingId],
  );
  return rows.map(mapPayment);
};

export const getPayment = async (db, bookingId, paymentId) => {
  const [rows] = await db.query(
    `SELECT ${PAYMENT_SELECT} FROM booking_payments WHERE id = ? AND booking_id = ? LIMIT 1`,
    [paymentId, bookingId],
  );
  return rows[0] ? mapPayment(rows[0]) : null;
};

// Sum of all scheduled instalment amounts (rows without an amount count as 0).
export const sumScheduledPayments = async (db, bookingId, { excludeId = null } = {}) => {
  const [rows] = await db.query(
    `SELECT COALESCE(SUM(amount), 0) AS total
       FROM booking_payments
      WHERE booking_id = ? ${excludeId ? "AND id <> ?" : ""}`,
    excludeId ? [bookingId, excludeId] : [bookingId],
  );
  return Number(rows[0].total);
};

export const nextPaymentSortOrder = async (db, bookingId) => {
  const [rows] = await db.query(
    `SELECT COALESCE(MAX(sort_order), 0) + 1 AS next FROM booking_payments WHERE booking_id = ?`,
    [bookingId],
  );
  return Number(rows[0].next);
};

export const insertPayment = async (db, bookingId, p, createdBy) => {
  const [result] = await db.query(
    `INSERT INTO booking_payments
       (booking_id, label, due_date, amount, payment_mode, paid_to, status,
        paid_date, remarks, sort_order, created_by)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      bookingId, p.label ?? null, p.due_date ?? null, p.amount ?? null,
      p.payment_mode ?? null, p.paid_to ?? "Driver", p.status ?? "Pending",
      p.paid_date ?? null, p.remarks ?? null, p.sort_order ?? 0, createdBy ?? null,
    ],
  );
  return result.insertId;
};

const UPDATABLE_PAYMENT_COLUMNS = new Set([
  "label", "due_date", "amount", "payment_mode", "paid_to", "status",
  "paid_date", "remarks", "sort_order",
]);

export const updatePayment = async (db, bookingId, paymentId, fields) => {
  const sets = [];
  const values = [];
  for (const [col, val] of Object.entries(fields)) {
    if (!UPDATABLE_PAYMENT_COLUMNS.has(col)) continue;
    sets.push(`\`${col}\` = ?`);
    values.push(val);
  }
  if (!sets.length) return;
  values.push(paymentId, bookingId);
  await db.query(
    `UPDATE booking_payments SET ${sets.join(", ")} WHERE id = ? AND booking_id = ?`,
    values,
  );
};

export const deletePayment = async (db, bookingId, paymentId) => {
  const [result] = await db.query(
    `DELETE FROM booking_payments WHERE id = ? AND booking_id = ?`,
    [paymentId, bookingId],
  );
  return result.affectedRows > 0;
};

/* ============================================================
 * LIST (paginated)
 * ============================================================ */

export const listBookings = async ({
  page = 1,
  limit = 50,
  search = "",
  status = "",
  from = null,
  to = null,
  createdBy = null,
}) => {
  const offset = (page - 1) * limit;

  // Everything except the status filter: used for the status tab counts.
  let where = `WHERE 1 = 1`;
  const values = [];

  if (createdBy) {
    where += ` AND b.created_by = ?`;
    values.push(createdBy);
  }

  if (from) {
    where += ` AND b.travel_from >= ?`;
    values.push(from);
  }
  if (to) {
    where += ` AND b.travel_from <= ?`;
    values.push(to);
  }

  if (search && search.trim()) {
    const like = `%${search.trim()}%`;
    where += ` AND (
      b.booking_no LIKE ?
      OR qt.quote_no LIKE ?
      OR CAST(b.lead_id AS CHAR) LIKE ?
      OR CONCAT_WS(' ', c.firstName, c.middleName, c.lastName) LIKE ?
      OR c.customerPhone LIKE ?
      OR c.alternatePhone LIKE ?
    )`;
    values.push(like, like, like, like, like, like);
  }

  const baseFrom = `
    FROM bookings b
    INNER JOIN quotations qt ON qt.id = b.quotation_id
    LEFT JOIN customers c ON c.id = b.customer_id
  `;

  const [countRows] = await pool.query(
    `SELECT
       COUNT(*) AS total,
       SUM(b.status = 'Pending')   AS pending_count,
       SUM(b.status = 'Confirmed') AS confirmed_count,
       SUM(b.status = 'Cancelled') AS cancelled_count
     ${baseFrom} ${where}`,
    values,
  );

  const statusCounts = {
    Pending: Number(countRows[0].pending_count) || 0,
    Confirmed: Number(countRows[0].confirmed_count) || 0,
    Cancelled: Number(countRows[0].cancelled_count) || 0,
  };
  const total = status ? statusCounts[status] ?? 0 : Number(countRows[0].total) || 0;

  const listWhere = status ? `${where} AND b.status = ?` : where;
  const listValues = status ? [...values, status] : values;

  const [rows] = await pool.query(
    `SELECT
       b.id, b.booking_no, b.booking_prefix, b.quotation_id, qt.quote_no,
       b.lead_id, b.customer_id,
       TRIM(CONCAT_WS(' ', c.firstName, c.middleName, c.lastName)) AS customer_name,
       c.customerPhone AS customer_phone,
       b.status, b.booking_amount, b.total_trip_cost,
       (b.total_trip_cost - b.booking_amount) AS balance_amount,
       ${D("b.travel_from", "travel_from")}, ${D("b.travel_to", "travel_to")},
       b.pickup_location, b.drop_location, b.trip_type, b.pax, b.total_days,
       (SELECT COALESCE(SUM(bv.no_of_vehicles), 0)
          FROM booking_vehicles bv WHERE bv.booking_id = b.id) AS vehicle_count,
       (SELECT GROUP_CONCAT(
                 CONCAT_WS(' ',
                   CASE WHEN bv.seats IS NULL THEN NULL ELSE CONCAT(bv.seats, ' Seat') END,
                   bv.vehicle_name)
                 ORDER BY bv.sr_no SEPARATOR ', ')
          FROM booking_vehicles bv WHERE bv.booking_id = b.id) AS vehicle_names,
       b.created_by, b.created_at, b.updated_at
     ${baseFrom}
     ${listWhere}
     ORDER BY b.created_at DESC, b.id DESC
     LIMIT ? OFFSET ?`,
    [...listValues, limit, offset],
  );

  const bookings = rows.map((r) => ({
    ...r,
    booking_amount: num(r.booking_amount),
    total_trip_cost: num(r.total_trip_cost),
    balance_amount: round2(num(r.balance_amount)),
    vehicle_count: Number(r.vehicle_count),
  }));

  return { bookings, total, statusCounts };
};

/* ============================================================
 * HRMS USER NAMES (created_by -> name). Never fails the request.
 * ============================================================ */

export const getUserNames = async (ids) => {
  const unique = [...new Set(ids.filter((id) => id !== null && id !== undefined))];
  if (!unique.length) return {};

  try {
    const placeholders = unique.map(() => "?").join(",");
    const [users] = await hrmsPool.query(
      `SELECT id, aliasName, firstName, lastName FROM users WHERE id IN (${placeholders})`,
      unique,
    );
    return Object.fromEntries(
      users.map((u) => [
        u.id,
        (u.aliasName || "").trim() ||
          `${u.firstName || ""} ${u.lastName || ""}`.trim() ||
          null,
      ]),
    );
  } catch (err) {
    console.error("hrmsPool user name fetch failed (booking):", err.message);
    return {};
  }
};
