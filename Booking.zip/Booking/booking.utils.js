import { ApiError } from "../../utils/ApiError.js";

/* ============================================================
 * CONSTANTS
 * ============================================================ */

export const BOOKING_STATUSES = ["Pending", "Confirmed", "Cancelled"];
export const PAYMENT_STATUSES = ["Pending", "Paid"];
export const PAID_TO_VALUES = ["Company", "Driver"];

// A booking can only be created from a quotation in one of these statuses.
// (quotations.status is Draft -> Sent -> Accepted / Rejected / Expired.
//  Nothing sets "Sent" yet, so Draft must be allowed too.)
export const BOOKABLE_QUOTATION_STATUSES = ["Draft", "Sent"];

/* ============================================================
 * BOOKING ID
 * ============================================================
 *
 * >>> CHANGE THE BOOKING ID FORMAT HERE (this is the only place) <<<
 *
 * Today:   PREFIX + booking id padded to 5 digits      ->  ST00021
 *
 * DEFAULT_BOOKING_PREFIX
 *   The "ST" part. It is only the DEFAULT: every booking stores its own
 *   booking_prefix, which can be sent on create and edited later via
 *   PATCH /booking/:id  (booking_no is rebuilt when the prefix changes).
 *   Change the constant below to change the default for new bookings.
 *
 * buildBookingNo() receives everything that could become part of the ID:
 *   prefix       - "ST"
 *   bookingId    - bookings.id (unique, auto increment)
 *   quotationId  - quotations.id this booking came from
 *   vendorId     - NOT USED YET. The vendor-based part of the ID will be
 *                  added later; the call sites already pass `vendorId`
 *                  (currently null) so only this function needs to change.
 */
export const DEFAULT_BOOKING_PREFIX = "ST";

export const buildBookingNo = ({
  prefix = DEFAULT_BOOKING_PREFIX,
  bookingId,
  // eslint-disable-next-line no-unused-vars
  quotationId = null,
  // eslint-disable-next-line no-unused-vars
  vendorId = null, // TODO(booking-id): vendor-based part goes here later
}) => {
  const cleanPrefix = normalizePrefix(prefix);
  return `${cleanPrefix}${String(bookingId).padStart(5, "0")}`;
};

export const normalizePrefix = (value) => {
  const prefix = String(value ?? "")
    .trim()
    .toUpperCase();

  if (!/^[A-Z0-9]{1,10}$/.test(prefix)) {
    throw new ApiError(
      400,
      "booking_prefix must be 1-10 letters or digits (A-Z, 0-9)",
    );
  }
  return prefix;
};

/* ============================================================
 * GENERIC VALIDATORS
 * ============================================================ */

export const isBlank = (v) =>
  v === undefined || v === null || (typeof v === "string" && v.trim() === "");

export const hasOwn = (obj, key) =>
  obj !== null &&
  typeof obj === "object" &&
  Object.prototype.hasOwnProperty.call(obj, key);

export const round2 = (n) => Math.round((Number(n) + Number.EPSILON) * 100) / 100;

export const parseId = (value, field = "id") => {
  const n = Number(value);
  if (!Number.isInteger(n) || n <= 0) {
    throw new ApiError(400, `${field} must be a positive integer`);
  }
  return n;
};

// Money: >= 0, max 2 decimals worth of precision, fits decimal(12,2)
export const toMoney = (value, field) => {
  const n = typeof value === "string" ? Number(value.trim()) : Number(value);
  if (isBlank(value) || !Number.isFinite(n) || n < 0 || n > 9999999999.99) {
    throw new ApiError(400, `${field} must be a number between 0 and 9999999999.99`);
  }
  return round2(n);
};

export const toIntInRange = (value, field, { min = 0, max = 65535 } = {}) => {
  const n = typeof value === "string" ? Number(value.trim()) : Number(value);
  if (isBlank(value) || !Number.isInteger(n) || n < min || n > max) {
    throw new ApiError(400, `${field} must be a whole number between ${min} and ${max}`);
  }
  return n;
};

export const toText = (value, field, max) => {
  if (isBlank(value)) return null;
  const s = String(value).trim();
  if (max && s.length > max) {
    throw new ApiError(400, `${field} must be at most ${max} characters`);
  }
  return s;
};

export const toEnum = (value, field, allowed) => {
  const match = allowed.find(
    (a) => a.toLowerCase() === String(value ?? "").trim().toLowerCase(),
  );
  if (!match) {
    throw new ApiError(400, `${field} must be one of: ${allowed.join(", ")}`);
  }
  return match; // canonical casing
};

// Accepts "YYYY-MM-DD" or an ISO datetime ("2026-11-05T06:30"); keeps the date part.
export const toDate = (value, field) => {
  if (isBlank(value)) return null;
  const s = String(value).trim().slice(0, 10);
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
  if (!m) throw new ApiError(400, `${field} must be a date (YYYY-MM-DD)`);
  const [y, mo, d] = [Number(m[1]), Number(m[2]), Number(m[3])];
  const probe = new Date(Date.UTC(y, mo - 1, d));
  if (
    probe.getUTCFullYear() !== y ||
    probe.getUTCMonth() !== mo - 1 ||
    probe.getUTCDate() !== d
  ) {
    throw new ApiError(400, `${field} is not a valid calendar date`);
  }
  return s;
};

// Accepts "HH:MM", "HH:MM:SS" or a datetime ("2026-11-05T06:30", "2026-11-05 06:30:00").
export const toTime = (value, field) => {
  if (isBlank(value)) return null;
  let s = String(value).trim();
  const sep = s.search(/[T ]/);
  if (sep !== -1 && /^\d{4}-\d{2}-\d{2}/.test(s)) s = s.slice(sep + 1);
  s = s.replace(/(Z|[+-]\d{2}:?\d{2})$/, "").replace(/\.\d+$/, "");

  const m = /^(\d{1,2}):(\d{2})(?::(\d{2}))?$/.exec(s);
  if (!m) throw new ApiError(400, `${field} must be a time (HH:MM)`);
  const [h, mi, se] = [Number(m[1]), Number(m[2]), Number(m[3] ?? 0)];
  if (h > 23 || mi > 59 || se > 59) {
    throw new ApiError(400, `${field} is not a valid time`);
  }
  const p = (n) => String(n).padStart(2, "0");
  return `${p(h)}:${p(mi)}:${p(se)}`;
};

// Today in India (the DB session runs in UTC, so never use CURDATE() for this)
export const todayIST = () =>
  new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Kolkata" });

/* ============================================================
 * TRAVEL FIELDS  (copied from the quotation, editable on the booking)
 * ============================================================ */

export const TRAVEL_FIELDS = [
  "travel_detail",
  "pickup_location",
  "pickup_time",
  "drop_location",
  "drop_time",
  "travel_from",
  "travel_to",
  "total_days",
  "trip_type",
  "pax",
  "remarks",
];

// Only keys that are PRESENT in `input` are returned, so this works for both
// create (merged over the quotation values) and PATCH (partial update).
export const normalizeTravelFields = (input = {}) => {
  const out = {};
  const has = (k) => hasOwn(input, k) && input[k] !== undefined;

  if (has("travel_detail")) {
    // The quotation stores the itinerary as a JSON string. Accept an array too.
    const v = input.travel_detail;
    out.travel_detail = Array.isArray(v) ? JSON.stringify(v) : toText(v, "travel_detail");
  }
  if (has("pickup_location")) out.pickup_location = toText(input.pickup_location, "pickup_location", 150);
  if (has("drop_location")) out.drop_location = toText(input.drop_location, "drop_location", 150);
  if (has("pickup_time")) out.pickup_time = toTime(input.pickup_time, "pickup_time");
  if (has("drop_time")) out.drop_time = toTime(input.drop_time, "drop_time");
  if (has("travel_from")) out.travel_from = toDate(input.travel_from, "travel_from");
  if (has("travel_to")) out.travel_to = toDate(input.travel_to, "travel_to");
  if (has("total_days")) {
    out.total_days = isBlank(input.total_days)
      ? null
      : toIntInRange(input.total_days, "total_days", { min: 0, max: 65535 });
  }
  if (has("pax")) {
    out.pax = isBlank(input.pax)
      ? null
      : toIntInRange(input.pax, "pax", { min: 0, max: 65535 });
  }
  if (has("trip_type")) out.trip_type = toText(input.trip_type, "trip_type", 30);
  if (has("remarks")) out.remarks = toText(input.remarks, "remarks");

  return out;
};

// Quotation row -> travel values exactly as stored (no re-validation: this is
// data we already hold, and the booking uses the same column types).
export const travelFromQuotation = (q) => ({
  travel_detail: q.travel_detail ?? null,
  pickup_location: q.pickup_location ?? null,
  pickup_time: q.pickup_time ?? null,
  drop_location: q.drop_location ?? null,
  drop_time: q.drop_time ?? null,
  travel_from: q.travel_from ?? null,
  travel_to: q.travel_to ?? null,
  total_days: q.total_days ?? null,
  trip_type: q.trip_type ?? null,
  pax: q.pax ?? null,
  remarks: q.remarks ?? null,
});

/* ============================================================
 * VEHICLES / CHARGES / NOTES
 * ============================================================ */

// input: [{ quotation_option_id, price?, no_of_vehicles?, description? }]
// optionsById: Map of quotation_vehicle_options rows for THIS quotation.
// Name / seats / category / sr_no always come from the quotation option;
// price, no_of_vehicles and description are editable.
export const buildVehicleRows = (input, optionsById) => {
  if (!Array.isArray(input) || input.length === 0) {
    throw new ApiError(400, "vehicles must be a non-empty array");
  }

  const seen = new Set();

  return input.map((v, i) => {
    const where = `vehicles[${i}]`;
    const optionId = parseId(v?.quotation_option_id, `${where}.quotation_option_id`);

    if (seen.has(optionId)) {
      throw new ApiError(
        400,
        `${where}: quotation_option_id ${optionId} is repeated (use no_of_vehicles for quantity)`,
      );
    }
    seen.add(optionId);

    const option = optionsById.get(optionId);
    if (!option) {
      throw new ApiError(
        400,
        `${where}: vehicle option ${optionId} does not belong to this quotation`,
      );
    }

    return {
      quotation_option_id: optionId,
      sr_no: option.sr_no,
      seats: option.seats ?? null,
      vehicle_name: option.vehicle_name ?? null,
      category_name: option.category_name ?? null,
      no_of_vehicles: hasOwn(v, "no_of_vehicles") && !isBlank(v.no_of_vehicles)
        ? toIntInRange(v.no_of_vehicles, `${where}.no_of_vehicles`, { min: 1, max: 1000 })
        : option.no_of_vehicles ?? 1,
      description: hasOwn(v, "description")
        ? toText(v.description, `${where}.description`)
        : option.description ?? null,
      price: hasOwn(v, "price") && !isBlank(v.price)
        ? toMoney(v.price, `${where}.price`)
        : round2(option.discounted_price ?? 0),
    };
  });
};

export const calcVehiclesTotal = (rows) =>
  round2(rows.reduce((sum, r) => sum + Number(r.price) * Number(r.no_of_vehicles), 0));

export const normalizeCharges = (input) => {
  if (!Array.isArray(input)) throw new ApiError(400, "charges must be an array");
  return input.map((c, i) => {
    const name = toText(c?.charge_name, `charges[${i}].charge_name`, 100);
    if (!name) throw new ApiError(400, `charges[${i}].charge_name is required`);
    return {
      charge_name: name,
      charge_detail: toText(c?.charge_detail, `charges[${i}].charge_detail`),
      is_included: c?.is_included ? 1 : 0,
      sort_order: i + 1,
    };
  });
};

export const normalizeNotes = (input) => {
  if (!Array.isArray(input)) throw new ApiError(400, "notes must be an array");
  return input.map((n, i) => {
    const text = toText(n?.note_text, `notes[${i}].note_text`);
    if (!text) throw new ApiError(400, `notes[${i}].note_text is required`);
    return { note_text: text, sort_order: i + 1 };
  });
};

/* ============================================================
 * PAYMENTS (balance instalments)
 * ============================================================ */

// `partial = true` for PATCH: only keys present are returned.
export const normalizePayment = (input = {}, { partial = false } = {}) => {
  const out = {};
  const has = (k) => hasOwn(input, k) && input[k] !== undefined;

  if (has("label")) out.label = toText(input.label, "label", 100);
  if (has("due_date")) out.due_date = toDate(input.due_date, "due_date");
  if (has("amount")) out.amount = isBlank(input.amount) ? null : toMoney(input.amount, "amount");
  if (has("payment_mode")) out.payment_mode = toText(input.payment_mode, "payment_mode", 50);
  if (has("paid_to")) out.paid_to = toEnum(input.paid_to, "paid_to", PAID_TO_VALUES);
  if (has("status")) out.status = toEnum(input.status, "status", PAYMENT_STATUSES);
  if (has("paid_date")) out.paid_date = toDate(input.paid_date, "paid_date");
  if (has("remarks")) out.remarks = toText(input.remarks, "remarks", 255);
  if (has("sort_order")) out.sort_order = toIntInRange(input.sort_order, "sort_order", { min: 0, max: 65535 });

  if (!partial) {
    const hasContent =
      out.label || out.due_date || (out.amount !== undefined && out.amount !== null);
    if (!hasContent) {
      throw new ApiError(400, "A payment row needs at least a label, due_date or amount");
    }
  }

  return out;
};
