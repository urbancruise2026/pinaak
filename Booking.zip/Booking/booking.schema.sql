-- =====================================================================
-- PINAAK  |  BOOKING CONFIRMATION MODULE  |  database schema
-- Run on the Pinaak database (the one behind `pool`), NOT the HRMS one.
--
-- Depends on existing tables: customers, leads, quotations,
--                             quotation_vehicle_options
-- Safe to re-run (CREATE TABLE IF NOT EXISTS).
-- Rollback: see the DROP statements at the bottom of this file.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. bookings  (one row per confirmed / pending / cancelled booking)
--
--    * ONE booking per quotation  -> UNIQUE (quotation_id)
--    * Travel columns are a COPY of the quotation, using the SAME column
--      types as `quotations`, so they can be edited here without ever
--      touching the quotation.
--    * total_trip_cost is calculated from booking_vehicles, but can be
--      typed in by hand. total_cost_manual = 1 means "typed by hand" and
--      stops automatic recalculation when vehicles change.
--    * balance is NOT stored: balance = total_trip_cost - booking_amount
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `bookings` (
  `id`                bigint unsigned NOT NULL AUTO_INCREMENT,

  -- Booking ID shown to the customer, e.g. ST00021.
  -- Built by buildBookingNo() in booking.utils.js (change the layout there).
  `booking_no`        varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  -- The "ST" part. Editable per booking; default lives in booking.utils.js.
  `booking_prefix`    varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ST',

  `quotation_id`      bigint unsigned NOT NULL,
  `lead_id`           bigint unsigned DEFAULT NULL,
  `customer_id`       bigint NOT NULL,

  `status`            enum('Pending','Confirmed','Cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',

  -- Money (INR)
  `booking_amount`    decimal(12,2) NOT NULL DEFAULT '0.00',
  `total_trip_cost`   decimal(12,2) NOT NULL DEFAULT '0.00',
  `total_cost_manual` tinyint(1) NOT NULL DEFAULT '0',

  -- Travel requirement (copied from quotation, editable)
  `travel_detail`     text COLLATE utf8mb4_unicode_ci,
  `pickup_location`   varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pickup_time`       time DEFAULT NULL,
  `drop_location`     varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `drop_time`         time DEFAULT NULL,
  `travel_from`       date DEFAULT NULL,
  `travel_to`         date DEFAULT NULL,
  `total_days`        smallint unsigned DEFAULT NULL,
  `trip_type`         varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pax`               smallint unsigned DEFAULT NULL,
  `remarks`           text COLLATE utf8mb4_unicode_ci,

  `cancel_reason`     varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `confirmed_at`      timestamp NULL DEFAULT NULL,
  `cancelled_at`      timestamp NULL DEFAULT NULL,

  -- HRMS user ids (no FK: users live in the other database)
  `created_by`        int unsigned DEFAULT NULL,
  `updated_by`        int unsigned DEFAULT NULL,
  `created_at`        timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`        timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_booking_no` (`booking_no`),
  UNIQUE KEY `uq_booking_quotation` (`quotation_id`),
  KEY `idx_b_lead` (`lead_id`),
  KEY `idx_b_customer` (`customer_id`),
  KEY `idx_b_status` (`status`),
  KEY `idx_b_travel_from` (`travel_from`),
  KEY `idx_b_created_by` (`created_by`),
  KEY `idx_b_created_at` (`created_at`),
  CONSTRAINT `fk_b_quotation` FOREIGN KEY (`quotation_id`) REFERENCES `quotations` (`id`),
  CONSTRAINT `fk_b_lead`      FOREIGN KEY (`lead_id`)      REFERENCES `leads` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_b_customer`  FOREIGN KEY (`customer_id`)  REFERENCES `customers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------------------------------------
-- 2. booking_vehicles  (ONLY the vehicle options the customer chose)
--
--    quotation_option_id points at quotation_vehicle_options.id. It has
--    no foreign key on purpose: this row is a snapshot, so changes to the
--    quotation must never block or alter the booking.
--    sr_no keeps the quotation's "#" (e.g. option 5 stays 5).
--    price = per-vehicle rate, editable. Line total = price * no_of_vehicles.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `booking_vehicles` (
  `id`                  bigint unsigned NOT NULL AUTO_INCREMENT,
  `booking_id`          bigint unsigned NOT NULL,
  `quotation_option_id` bigint unsigned NOT NULL,
  `sr_no`               smallint unsigned NOT NULL,
  `seats`               smallint unsigned DEFAULT NULL,
  `vehicle_name`        varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_name`       varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_of_vehicles`      smallint unsigned NOT NULL DEFAULT '1',
  `description`         text COLLATE utf8mb4_unicode_ci,
  `price`               decimal(12,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_bv_booking_option` (`booking_id`,`quotation_option_id`),
  KEY `idx_bv_booking` (`booking_id`),
  CONSTRAINT `fk_bv_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------------------------------------
-- 3. booking_charges  ("Other charges" block, copied from quotation, editable)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `booking_charges` (
  `id`            bigint unsigned NOT NULL AUTO_INCREMENT,
  `booking_id`    bigint unsigned NOT NULL,
  `charge_name`   varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `charge_detail` text COLLATE utf8mb4_unicode_ci,
  `is_included`   tinyint(1) NOT NULL DEFAULT '0',
  `sort_order`    smallint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bc_booking` (`booking_id`),
  CONSTRAINT `fk_bc_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------------------------------------
-- 4. booking_notes  (copied from quotation, editable)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `booking_notes` (
  `id`         bigint unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` bigint unsigned NOT NULL,
  `note_text`  text COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` smallint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bn_booking` (`booking_id`),
  CONSTRAINT `fk_bn_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------------------------------------
-- 5. booking_payments  (balance payment instalments)
--
--    Example rows from the template:
--      04-Apr | 10000 | Gpay/UPI | Driver | Pending
--      10-Apr | NULL  | Cash     | Driver | Pending   (label "Extra KM/Parking")
--    amount is nullable for rows that have no fixed amount.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `booking_payments` (
  `id`           bigint unsigned NOT NULL AUTO_INCREMENT,
  `booking_id`   bigint unsigned NOT NULL,
  `label`        varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `due_date`     date DEFAULT NULL,
  `amount`       decimal(12,2) DEFAULT NULL,
  `payment_mode` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_to`      enum('Company','Driver') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Driver',
  `status`       enum('Pending','Paid') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `paid_date`    date DEFAULT NULL,
  `remarks`      varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order`   smallint unsigned NOT NULL DEFAULT '0',
  `created_by`   int unsigned DEFAULT NULL,
  `created_at`   timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`   timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_bp_booking` (`booking_id`),
  KEY `idx_bp_due` (`due_date`),
  KEY `idx_bp_status` (`status`),
  CONSTRAINT `fk_bp_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------------------------------------
-- ROLLBACK (only if you need to remove the module; deletes all booking data)
-- ---------------------------------------------------------------------
-- DROP TABLE IF EXISTS `booking_payments`;
-- DROP TABLE IF EXISTS `booking_notes`;
-- DROP TABLE IF EXISTS `booking_charges`;
-- DROP TABLE IF EXISTS `booking_vehicles`;
-- DROP TABLE IF EXISTS `bookings`;
