import { pool } from "../../config/mySqlDB.js";
import { ApiError } from "../../utils/ApiError.js";
import * as M from "./booking.model.js";
import {
  BOOKING_STATUSES,
  BOOKABLE_QUOTATION_STATUSES,
  DEFAULT_BOOKING_PREFIX,
  TRAVEL_FIELDS,
  buildBookingNo,
  buildVehicleRows,
  calcVehiclesTotal,
  hasOwn,
  isBlank,
  normalizeCharges,
  normalizeNotes,
  normalizePayment,
  normalizePrefix,
  normalizeTravelFields,
  parseId,
  round2,
  toDate,
  toEnum,
  toMoney,
  toText,
  todayIST,
  travelFromQuotation,
} from "./booking.utils.js";

/* ============================================================
 * INTERNAL HELPERS
 * ============================================================ */

const withTransaction = async (fn) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const result = await fn(conn);
    await conn.commit();
    return result;
  } catch (err) {
    try {
      await conn.rollback();
    } catch (rollbackErr) {
      console.error("booking rollback failed:", rollbackErr.message);
    }

    // Unique keys are the final guard against double booking / duplicate IDs.
    if (err?.code === "ER_DUP_ENTRY") {
      if (String(err.message).includes("uq_booking_quotation")) {
        throw new ApiError(409, "A booking already exists for this quotation");
      }
      if (String(err.message).includes("uq_booking_no")) {
        throw new ApiError(409, "This booking number is already in use");
      }
    }
    throw err;
  } finally {
    conn.release();
  }
};

// ---- Who can see which bookings -------------------------------------
// Travel advisors only see bookings they created; everyone else with
// access to the module sees all bookings. If you need zone / city scoping
// (like rate.controller.js does for City Managers) add it here.
const isTravelAdvisor = (user) =>
  String(user?.role_name ?? "").trim().toLowerCase() === "travel advisor";

const advisorScope = (user) => (isTravelAdvisor(user) ? Number(user.id) : null);

const assertAccess = (booking, user) => {
  if (isTravelAdvisor(user) && Number(booking.created_by) !== Number(user.id)) {
    throw new ApiError(403, "You do not have access to this booking");
  }
};

const loadBooking = async (db, id, user, { lock = false } = {}) => {
  const booking = await M.getBookingRow(db, id, { lock });
  if (!booking) throw new ApiError(404, "Booking not found");
  assertAccess(booking, user);
  return booking;
};

// ---- Upstream status sync -------------------------------------------
// When a booking becomes Confirmed the lead moves to BOOK (with a row in
// lead_status_history). This is the ONLY place the booking module writes to
// the leads table. Remove the calls to markLeadBooked() to turn it off.
const markLeadBooked = async (conn, leadId, user) => {
  if (!leadId) return;
  const lead = await M.getLeadStatus(conn, leadId);
  if (!lead || lead.status === "BOOK") return;

  await M.setLeadStatus(conn, leadId, "BOOK");
  await M.insertLeadStatusHistory(conn, {
    lead_id: leadId,
    old_status: lead.status,
    new_status: "BOOK",
    changed_by: user?.id ?? null,
  });
};

const pickTravel = (body = {}) =>
  Object.fromEntries(TRAVEL_FIELDS.filter((k) => hasOwn(body, k)).map((k) => [k, body[k]]));

const buildPaymentSummary = (booking, payments) => {
  const balance = round2(booking.total_trip_cost - booking.booking_amount);
  const sum = (rows) => round2(rows.reduce((s, p) => s + (p.amount ?? 0), 0));
  const scheduled = sum(payments);
  const paid = sum(payments.filter((p) => p.status === "Paid"));

  return {
    total_trip_cost: booking.total_trip_cost,
    booking_amount: booking.booking_amount,
    balance_amount: balance,
    scheduled_amount: scheduled, // all instalments with an amount
    paid_amount: paid, // instalments marked Paid
    pending_amount: round2(balance - paid), // balance still to be collected
    unscheduled_amount: round2(balance - scheduled), // balance with no instalment yet
  };
};

// Full booking confirmation view (everything the page needs in one response).
const fetchFullView = async (db, id) => {
  const booking = await M.getBookingRow(db, id);
  if (!booking) throw new ApiError(404, "Booking not found");

  const [customer, quotation, vehicles, charges, notes, payments, names] =
    await Promise.all([
      M.getCustomer(db, booking.customer_id),
      M.getQuotationSummary(db, booking.quotation_id),
      M.listVehicles(db, id),
      M.listCharges(db, id),
      M.listNotes(db, id),
      M.listPayments(db, id),
      M.getUserNames([booking.created_by, booking.updated_by]),
    ]);

  return {
    ...booking,
    created_by_name: names[booking.created_by] ?? null,
    updated_by_name: names[booking.updated_by] ?? null,
    customer,
    quotation,
    vehicles,
    charges,
    notes,
    payments,
    payment_summary: buildPaymentSummary(booking, payments),
  };
};

/* ============================================================
 * PREFILL  (GET /booking/from-quotation/:quotationId)
 * What the booking confirmation form shows before anything is saved.
 * ============================================================ */

export const getBookingPrefill = async (quotationIdRaw) => {
  const quotationId = parseId(quotationIdRaw, "quotationId");

  const quotation = await M.getQuotationForBooking(pool, quotationId);
  if (!quotation) throw new ApiError(404, "Quotation not found");

  const [customer, options, charges, notes, existing] = await Promise.all([
    M.getCustomer(pool, quotation.customer_id),
    M.getQuotationOptions(pool, quotationId),
    M.getQuotationCharges(pool, quotationId),
    M.getQuotationNotes(pool, quotationId),
    M.getBookingByQuotationId(pool, quotationId),
  ]);

  let notBookableReason = null;
  if (existing) {
    notBookableReason = `Booking ${existing.booking_no} already exists for this quotation`;
  } else if (!BOOKABLE_QUOTATION_STATUSES.includes(quotation.status)) {
    notBookableReason = `Quotation is ${quotation.status}`;
  } else if (options.length === 0) {
    notBookableReason = "Quotation has no vehicle options";
  }

  return {
    quotation: {
      id: quotation.id,
      quote_no: quotation.quote_no,
      status: quotation.status,
      quote_date: quotation.quote_date,
      lead_id: quotation.lead_id,
      customer_id: quotation.customer_id,
    },
    bookable: notBookableReason === null,
    not_bookable_reason: notBookableReason,
    existing_booking: existing,
    customer,
    travel: travelFromQuotation(quotation),
    vehicle_options: options.map((o) => ({
      quotation_option_id: o.id,
      sr_no: o.sr_no,
      seats: o.seats,
      vehicle_name: o.vehicle_name,
      category_name: o.category_name,
      no_of_vehicles: o.no_of_vehicles,
      description: o.description,
      price: o.discounted_price,
      line_total: round2(o.discounted_price * o.no_of_vehicles),
    })),
    charges: charges.map((c) => ({ ...c, is_included: Boolean(c.is_included) })),
    notes,
    defaults: {
      booking_prefix: DEFAULT_BOOKING_PREFIX,
      status: "Pending",
      booking_amount: 0,
    },
  };
};

/* ============================================================
 * CREATE  (POST /booking)
 * ============================================================ */

export const createBooking = async (body = {}, user) => {
  const quotationId = parseId(body.quotation_id, "quotation_id");

  const status = isBlank(body.status)
    ? "Pending"
    : toEnum(body.status, "status", BOOKING_STATUSES);
  const prefix = isBlank(body.booking_prefix)
    ? DEFAULT_BOOKING_PREFIX
    : normalizePrefix(body.booking_prefix);
  const bookingAmount = isBlank(body.booking_amount)
    ? 0
    : toMoney(body.booking_amount, "booking_amount");
  const manualTotal = isBlank(body.total_trip_cost)
    ? null
    : toMoney(body.total_trip_cost, "total_trip_cost");
  const travelOverrides = normalizeTravelFields(pickTravel(body));

  const bookingId = await withTransaction(async (conn) => {
    // Lock the quotation so two people cannot book it at the same moment.
    const quotation = await M.getQuotationForBooking(conn, quotationId, { lock: true });
    if (!quotation) throw new ApiError(404, "Quotation not found");

    const existing = await M.getBookingByQuotationId(conn, quotationId);
    if (existing) {
      throw new ApiError(409, `Booking ${existing.booking_no} already exists for this quotation`);
    }
    if (!BOOKABLE_QUOTATION_STATUSES.includes(quotation.status)) {
      throw new ApiError(
        409,
        `Quotation ${quotation.quote_no} is ${quotation.status}. Only ${BOOKABLE_QUOTATION_STATUSES.join(" or ")} quotations can be booked`,
      );
    }

    // Vehicles: only options that exist on this quotation.
    const options = await M.getQuotationOptions(conn, quotationId);
    const optionsById = new Map(options.map((o) => [Number(o.id), o]));
    const vehicleRows = buildVehicleRows(body.vehicles, optionsById);

    // Charges / notes: use what the form sent, otherwise copy the quotation's.
    const charges = normalizeCharges(
      hasOwn(body, "charges") ? body.charges : await M.getQuotationCharges(conn, quotationId),
    );
    const notes = normalizeNotes(
      hasOwn(body, "notes") ? body.notes : await M.getQuotationNotes(conn, quotationId),
    );

    const total = manualTotal ?? calcVehiclesTotal(vehicleRows);
    if (bookingAmount > total) {
      throw new ApiError(400, "booking_amount cannot be more than total_trip_cost");
    }

    const travel = { ...travelFromQuotation(quotation), ...travelOverrides };

    // Placeholder number; the real one needs the auto-increment id.
    const placeholder = `TMP-${Date.now()}-${Math.floor(Math.random() * 1e6)}`;

    const id = await M.insertBooking(conn, {
      booking_no: placeholder,
      booking_prefix: prefix,
      quotation_id: quotationId,
      lead_id: quotation.lead_id ?? null,
      customer_id: quotation.customer_id,
      status,
      booking_amount: bookingAmount,
      total_trip_cost: total,
      total_cost_manual: manualTotal !== null,
      ...travel,
      created_by: user?.id ?? null,
    });

    await M.updateBookingFields(conn, id, {
      booking_no: buildBookingNo({
        prefix,
        bookingId: id,
        quotationId,
        vendorId: null, // vendor part of the ID: later
      }),
    });

    await M.replaceVehicles(conn, id, vehicleRows);
    await M.replaceCharges(conn, id, charges);
    await M.replaceNotes(conn, id, notes);

    // Booking taken up -> quotation is Accepted.
    await M.setQuotationStatus(conn, quotationId, "Accepted");

    if (status === "Confirmed") await markLeadBooked(conn, quotation.lead_id, user);

    return id;
  });

  return fetchFullView(pool, bookingId);
};

/* ============================================================
 * READ
 * ============================================================ */

export const getBooking = async (idRaw, user) => {
  const id = parseId(idRaw, "id");
  await loadBooking(pool, id, user);
  return fetchFullView(pool, id);
};

export const listBookingsForUser = async (query = {}, user) => {
  const page = Math.max(1, parseInt(query.page, 10) || 1);
  const limit = Math.min(100, Math.max(1, parseInt(query.limit, 10) || 50));
  const status = isBlank(query.status) ? "" : toEnum(query.status, "status", BOOKING_STATUSES);

  const { bookings, total, statusCounts } = await M.listBookings({
    page,
    limit,
    search: typeof query.search === "string" ? query.search : "",
    status,
    from: toDate(query.from, "from"),
    to: toDate(query.to, "to"),
    createdBy: advisorScope(user),
  });

  const names = await M.getUserNames(bookings.map((b) => b.created_by));
  const totalPages = Math.ceil(total / limit);

  return {
    bookings: bookings.map((b) => ({ ...b, created_by_name: names[b.created_by] ?? null })),
    page,
    limit,
    total,
    totalPages,
    hasNextPage: page < totalPages,
    selectedStatus: status || null,
    statusCounts,
  };
};

/* ============================================================
 * UPDATE  (PATCH /booking/:id)
 * status, booking_amount, total_trip_cost, booking_prefix,
 * cancel_reason and every travel field.
 * ============================================================ */

export const updateBooking = async (idRaw, body = {}, user) => {
  const id = parseId(idRaw, "id");

  await withTransaction(async (conn) => {
    const booking = await loadBooking(conn, id, user, { lock: true });

    const fields = {};
    const raw = {};

    // ---- status ----
    let status = booking.status;
    if (hasOwn(body, "status")) {
      status = toEnum(body.status, "status", BOOKING_STATUSES);
      fields.status = status;
    }

    // ---- prefix (rebuilds the booking number) ----
    if (hasOwn(body, "booking_prefix")) {
      const prefix = normalizePrefix(body.booking_prefix);
      if (prefix !== booking.booking_prefix) {
        fields.booking_prefix = prefix;
        fields.booking_no = buildBookingNo({
          prefix,
          bookingId: booking.id,
          quotationId: booking.quotation_id,
          vendorId: null,
        });
      }
    }

    // ---- money ----
    let bookingAmount = booking.booking_amount;
    let total = booking.total_trip_cost;
    let moneyTouched = false;

    if (hasOwn(body, "booking_amount")) {
      bookingAmount = toMoney(body.booking_amount, "booking_amount");
      fields.booking_amount = bookingAmount;
      moneyTouched = true;
    }

    if (hasOwn(body, "total_trip_cost") && body.recalculate_total === true) {
      throw new ApiError(400, "Send either total_trip_cost or recalculate_total, not both");
    }
    if (hasOwn(body, "total_trip_cost")) {
      total = toMoney(body.total_trip_cost, "total_trip_cost");
      fields.total_trip_cost = total;
      fields.total_cost_manual = 1; // typed by hand: stop auto-recalculation
      moneyTouched = true;
    } else if (body.recalculate_total === true) {
      total = calcVehiclesTotal(await M.listVehicles(conn, id));
      fields.total_trip_cost = total;
      fields.total_cost_manual = 0; // back to calculated
      moneyTouched = true;
    }

    if (moneyTouched && bookingAmount > total) {
      throw new ApiError(400, "booking_amount cannot be more than total_trip_cost");
    }

    // ---- travel + cancel reason ----
    Object.assign(fields, normalizeTravelFields(pickTravel(body)));
    if (hasOwn(body, "cancel_reason")) {
      fields.cancel_reason = toText(body.cancel_reason, "cancel_reason", 255);
    }

    // ---- status side effects ----
    if (status !== booking.status) {
      if (status === "Cancelled") {
        raw.cancelled_at = "NOW()";
      } else {
        raw.cancelled_at = "NULL";
        if (!hasOwn(body, "cancel_reason")) fields.cancel_reason = null;
        if (status === "Confirmed") raw.confirmed_at = "NOW()";
      }
    }

    if (Object.keys(fields).length === 0 && Object.keys(raw).length === 0) {
      throw new ApiError(400, "No valid fields to update");
    }

    fields.updated_by = user?.id ?? null;
    await M.updateBookingFields(conn, id, fields, raw);

    if (status === "Confirmed" && booking.status !== "Confirmed") {
      await markLeadBooked(conn, booking.lead_id, user);
    }
  });

  return fetchFullView(pool, id);
};

/* ============================================================
 * VEHICLES / CHARGES / NOTES  (PUT = replace the whole list)
 * ============================================================ */

export const setBookingVehicles = async (idRaw, vehicles, user) => {
  const id = parseId(idRaw, "id");

  await withTransaction(async (conn) => {
    const booking = await loadBooking(conn, id, user, { lock: true });

    const options = await M.getQuotationOptions(conn, booking.quotation_id);
    const optionsById = new Map(options.map((o) => [Number(o.id), o]));
    const rows = buildVehicleRows(vehicles, optionsById);

    await M.replaceVehicles(conn, id, rows);

    // Keep the total in step unless someone typed it in by hand.
    const fields = { updated_by: user?.id ?? null };
    if (!booking.total_cost_manual) fields.total_trip_cost = calcVehiclesTotal(rows);
    await M.updateBookingFields(conn, id, fields);
  });

  return fetchFullView(pool, id);
};

export const setBookingCharges = async (idRaw, charges, user) => {
  const id = parseId(idRaw, "id");

  await withTransaction(async (conn) => {
    await loadBooking(conn, id, user, { lock: true });
    await M.replaceCharges(conn, id, normalizeCharges(charges));
    await M.updateBookingFields(conn, id, { updated_by: user?.id ?? null });
  });

  return fetchFullView(pool, id);
};

export const setBookingNotes = async (idRaw, notes, user) => {
  const id = parseId(idRaw, "id");

  await withTransaction(async (conn) => {
    await loadBooking(conn, id, user, { lock: true });
    await M.replaceNotes(conn, id, normalizeNotes(notes));
    await M.updateBookingFields(conn, id, { updated_by: user?.id ?? null });
  });

  return fetchFullView(pool, id);
};

/* ============================================================
 * PAYMENTS (balance instalments)
 * Scheduled instalment amounts may not add up to more than the balance
 * (total_trip_cost - booking_amount).
 * ============================================================ */

const assertWithinBalance = (booking, scheduledTotal) => {
  const balance = Math.max(round2(booking.total_trip_cost - booking.booking_amount), 0);
  if (round2(scheduledTotal) > balance + 0.005) {
    throw new ApiError(
      400,
      `Instalments (${round2(scheduledTotal)}) cannot be more than the balance amount (${balance})`,
    );
  }
};

// Keep status and paid_date consistent.
const settlePaidDate = (status, paidDate) => {
  if (status === "Paid") return paidDate ?? todayIST();
  return null;
};

export const addBookingPayment = async (idRaw, body, user) => {
  const id = parseId(idRaw, "id");
  const payment = normalizePayment(body);

  await withTransaction(async (conn) => {
    const booking = await loadBooking(conn, id, user, { lock: true });

    const status = payment.status ?? "Pending";
    payment.status = status;
    payment.paid_date = settlePaidDate(status, payment.paid_date);
    if (payment.sort_order === undefined) {
      payment.sort_order = await M.nextPaymentSortOrder(conn, id);
    }

    const scheduled = (await M.sumScheduledPayments(conn, id)) + (payment.amount ?? 0);
    assertWithinBalance(booking, scheduled);

    await M.insertPayment(conn, id, payment, user?.id);
  });

  return fetchFullView(pool, id);
};

export const updateBookingPayment = async (idRaw, paymentIdRaw, body, user) => {
  const id = parseId(idRaw, "id");
  const paymentId = parseId(paymentIdRaw, "paymentId");
  const patch = normalizePayment(body, { partial: true });

  if (Object.keys(patch).length === 0) {
    throw new ApiError(400, "No valid fields to update");
  }

  await withTransaction(async (conn) => {
    const booking = await loadBooking(conn, id, user, { lock: true });

    const existing = await M.getPayment(conn, id, paymentId);
    if (!existing) throw new ApiError(404, "Payment not found");

    const status = patch.status ?? existing.status;
    patch.paid_date = settlePaidDate(
      status,
      hasOwn(patch, "paid_date") ? patch.paid_date : existing.paid_date,
    );

    const newAmount = hasOwn(patch, "amount") ? patch.amount : existing.amount;
    const scheduled =
      (await M.sumScheduledPayments(conn, id, { excludeId: paymentId })) + (newAmount ?? 0);
    assertWithinBalance(booking, scheduled);

    await M.updatePayment(conn, id, paymentId, patch);
  });

  return fetchFullView(pool, id);
};

export const deleteBookingPayment = async (idRaw, paymentIdRaw, user) => {
  const id = parseId(idRaw, "id");
  const paymentId = parseId(paymentIdRaw, "paymentId");

  await withTransaction(async (conn) => {
    await loadBooking(conn, id, user, { lock: true });
    const removed = await M.deletePayment(conn, id, paymentId);
    if (!removed) throw new ApiError(404, "Payment not found");
  });

  return fetchFullView(pool, id);
};
