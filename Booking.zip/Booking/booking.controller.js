import { asyncHandler } from "../../utils/asyncHandler.js";
import { ApiResponse } from "../../utils/ApiResponse.js";
import {
  getBookingPrefill,
  createBooking,
  getBooking,
  listBookingsForUser,
  updateBooking,
  setBookingVehicles,
  setBookingCharges,
  setBookingNotes,
  addBookingPayment,
  updateBookingPayment,
  deleteBookingPayment,
} from "./booking.service.js";

const ok = (res, data, message, status = 200) =>
  res.status(status).json(new ApiResponse(status, data, message));

// GET /booking/from-quotation/:quotationId
export const getPrefillController = asyncHandler(async (req, res) => {
  const data = await getBookingPrefill(req.params.quotationId);
  return ok(res, data, "Booking prefill fetched successfully");
});

// POST /booking
export const createBookingController = asyncHandler(async (req, res) => {
  const data = await createBooking(req.body, req.user);
  return ok(res, data, "Booking created successfully", 201);
});

// GET /booking
export const listBookingsController = asyncHandler(async (req, res) => {
  const data = await listBookingsForUser(req.query, req.user);
  return ok(
    res,
    data,
    data.bookings.length ? "Bookings fetched successfully" : "No bookings found",
  );
});

// GET /booking/:id
export const getBookingController = asyncHandler(async (req, res) => {
  const data = await getBooking(req.params.id, req.user);
  return ok(res, data, "Booking fetched successfully");
});

// PATCH /booking/:id
export const updateBookingController = asyncHandler(async (req, res) => {
  const data = await updateBooking(req.params.id, req.body, req.user);
  return ok(res, data, "Booking updated successfully");
});

// PUT /booking/:id/vehicles   body: { vehicles: [...] }
export const setVehiclesController = asyncHandler(async (req, res) => {
  const data = await setBookingVehicles(req.params.id, req.body?.vehicles, req.user);
  return ok(res, data, "Booking vehicles updated successfully");
});

// PUT /booking/:id/charges    body: { charges: [...] }
export const setChargesController = asyncHandler(async (req, res) => {
  const data = await setBookingCharges(req.params.id, req.body?.charges, req.user);
  return ok(res, data, "Booking charges updated successfully");
});

// PUT /booking/:id/notes      body: { notes: [...] }
export const setNotesController = asyncHandler(async (req, res) => {
  const data = await setBookingNotes(req.params.id, req.body?.notes, req.user);
  return ok(res, data, "Booking notes updated successfully");
});

// POST /booking/:id/payments
export const addPaymentController = asyncHandler(async (req, res) => {
  const data = await addBookingPayment(req.params.id, req.body, req.user);
  return ok(res, data, "Payment added successfully", 201);
});

// PATCH /booking/:id/payments/:paymentId
export const updatePaymentController = asyncHandler(async (req, res) => {
  const data = await updateBookingPayment(
    req.params.id,
    req.params.paymentId,
    req.body,
    req.user,
  );
  return ok(res, data, "Payment updated successfully");
});

// DELETE /booking/:id/payments/:paymentId
export const deletePaymentController = asyncHandler(async (req, res) => {
  const data = await deleteBookingPayment(req.params.id, req.params.paymentId, req.user);
  return ok(res, data, "Payment deleted successfully");
});
