import { Router } from "express";
import { verifyJWT } from "../../middlewares/auth.middleware.js";
import { ApiError } from "../../utils/ApiError.js";
import {
  getPrefillController,
  createBookingController,
  listBookingsController,
  getBookingController,
  updateBookingController,
  setVehiclesController,
  setChargesController,
  setNotesController,
  addPaymentController,
  updatePaymentController,
  deletePaymentController,
} from "./booking.controller.js";

const router = Router();

// verifyJWT also lets vendor / driver / customer tokens through.
// Booking confirmation is an internal (employee) screen only.
const employeeOnly = (req, res, next) => {
  if (req.user?.loginType !== "employee") {
    return next(new ApiError(403, "Booking is available to employees only"));
  }
  next();
};

router.use(verifyJWT, employeeOnly);

router.get("/", listBookingsController);

// must stay above "/:id"
router.get("/from-quotation/:quotationId", getPrefillController);

router.post("/", createBookingController);

router.get("/:id", getBookingController);
router.patch("/:id", updateBookingController);

router.put("/:id/vehicles", setVehiclesController);
router.put("/:id/charges", setChargesController);
router.put("/:id/notes", setNotesController);

router.post("/:id/payments", addPaymentController);
router.patch("/:id/payments/:paymentId", updatePaymentController);
router.delete("/:id/payments/:paymentId", deletePaymentController);

export default router;
